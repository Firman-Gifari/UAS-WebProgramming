<?php
require '../backend/conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $productId = $_POST['product_id'] ?? null;

        switch ($_POST['action']) {
            case 'increase':
                $conn->query("UPDATE keranjang SET quantity = quantity + 1 WHERE product_id = $productId");
                break;
            case 'decrease':
                $conn->query("UPDATE keranjang SET quantity = GREATEST(quantity - 1, 1) WHERE product_id = $productId");
                break;
            case 'remove':
                $conn->query("DELETE FROM keranjang WHERE product_id = $productId");
                break;
            case 'checkout':
                if (!empty($_POST['selected_products'])) {
                    foreach ($_POST['selected_products'] as $selectedProduct) {
                        $product = json_decode($selectedProduct, true);
                        $productId = $product['product_id'];
                        $varian = $product['varian'];
                        $ukuran = $product['ukuran'];

                        $stmt = $conn->prepare("DELETE FROM keranjang WHERE product_id = ? AND varian = ? AND ukuran = ?");
                        $stmt->execute([$productId, $varian, $ukuran]);
                    }
                    header('Location: cart.php?success=1&from=menushop');
                    exit;
                } else {
                    header('Location: cart.php?success=0&from=menushop');
                    exit;
                }
                break;
        }
    }
    header('Location: cart.php');
    exit;
}

  $keranjang = $conn->query("
      SELECT products.id as product_id, products.name, products.price, products.category, products.image_url, keranjang.quantity, keranjang.varian, keranjang.ukuran 
      FROM keranjang 
      JOIN products ON keranjang.product_id = products.id
    ")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Keranjang</title>
   
  </head>
  <body class="">
    <header class="flex items-center justify-between bg-indigo-600 py-4 px-10 text-white">
      <div class="flex items-center gap-2">
        <img
          id="btnBack"
          class="h-7 filter invert brightness-0 cursor-pointer"
          src="./img/arrowBack.png"
          alt="Kembali"
        />
        <h1 class="text-2xl font-bold">Keranjang</h1>
      </div>
      <div class="flex items-center gap-4">
        <button
          class="inline-flex items-center justify-center gap-1.5 rounded border border-indigo-600 bg-white px-5 py-3 text-gray-900 transition hover:text-gray-700 focus:outline-none focus:ring text-sm text-indigo-600 font-medium"
          type="button"
        >
          <a href="profile.html?from=cart"> Akun </a>
        </button>
      </div>
    </header>

    <section class="mt-5">
      <div
        class="mx-auto max-w-screen-xl px-10 py-2 mb-10 sm:px-6 sm:py-4 lg:px-10"
      >
        <div class="mx-auto">
            <div class="py-4">
            <ul class="space-y-4">
            <?php foreach ($keranjang as $item): ?>
              <li class="flex items-center gap-4 product-row" data-price="<?= htmlspecialchars($item['price']) ?>">
                <input type="checkbox" class="product-checkbox cursor-pointer" value="<?= $item['product_id'] ?>" onclick="updateTotal()" />
                <input type="hidden" class="product-varian" value="<?= htmlspecialchars($item['varian']) ?>" />
                <input type="hidden" class="product-ukuran" value="<?= htmlspecialchars($item['ukuran']) ?>" />

                <img
                  src="<?= htmlspecialchars($item['image_url']) ?>"
                  alt="<?= htmlspecialchars($item['name']) ?>"
                  class="h-16 w-16 rounded object-cover"
                />

                <div>
                  <h3 class="text-sm text-gray-900"> <?= htmlspecialchars($item['name']) ?></h3>
                  <dl class="mt-0.5 space-y-px text-[10px] text-gray-600">
                    <div>
                      <dt class="inline">Varian:</dt>
                      <dd class="inline"> <?= htmlspecialchars($item['varian']) ?></dd>
                    </div>

                    <div>
                      <dt class="inline">Ukuran:</dt>
                      <dd class="inline"> <?= htmlspecialchars($item['ukuran']) ?></dd>
                    </div>
                  </dl>
                </div>

                <div class="flex flex-1 items-center justify-end gap-2">
                  <button onclick="submitForm('decrease', <?= $item['product_id'] ?>)" class="text-gray-600 transition hover:text-red-600"> - </button>

                  <input
                    type="number"
                    min="1"
                    value="<?= htmlspecialchars($item['quantity']) ?>"
                    class="h-8 w-10 rounded border-gray-200 bg-gray-50 p-0 text-center text-xs text-gray-600 quantity-input"
                    readonly
                  />

                  <button onclick="submitForm('increase', <?= $item['product_id'] ?>)" class="text-gray-600 transition hover:text-green-600"> + </button>

                  <button onclick="submitForm('remove', <?= $item['product_id'] ?>)" class="text-gray-600 transition hover:text-red-600">
                    <span class="sr-only">Remove item</span>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke-width="1.5"
                      stroke="currentColor"
                      class="h-4 w-4"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
                      />
                    </svg>
                  </button>
                </div>
              </li>
              <?php endforeach; ?>
            </ul>

            <div
              class="flex flex-col justify-end border-t border-gray-100 pt-8"
            >
              <dl class="space-y-0.5 text-sm text-gray-700">
                <div class="flex justify-end !text-base font-medium">
                  <dt>Total Harga:</dt>
                  <dd class="ms-10" id="subtotal">Rp. 0</dd>
                </div>
              </dl>
              <br />
              <div class="flex justify-end">
                <button type="button" onclick="confirmCheckout()" class="block rounded bg-indigo-700 px-5 py-3 text-sm text-gray-100 transition hover:bg-indigo-600">
                  Checkout
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
 
    <footer>
      <div class="mx-auto max-w-screen-xl px-4 py-4 sm:px-6 lg:px-8">
        <div class="text-center">
          <p class="text-xs text-gray-600">
            @Copyright by 22552011189, 22552011041, 22552011074, 22552011171,
            22552011183_Kelompok 3 Aridwan, Davin Albar Pratama, Dzikri Ali
            Al-Hafidzi, Ega Sulanjana, Firman Gifari_TIF 22 CID
          </p>
        </div>
      </div>
    </footer>

    <script>
      document
        .getElementById("btnBack")
        .addEventListener("click", function () {
          const urlParams = new URLSearchParams(window.location.search);
          const fromPage = urlParams.get("from");

          if (fromPage === "landingpage") {
            window.location.href = "landingpage.html";
          } else {
            window.location.href = "menushop.php";
          } 
        });

      function updateTotal() {
        const checkboxes = document.querySelectorAll('.product-checkbox:checked');
        let total = 0;

        checkboxes.forEach(checkbox => {
          const productRow = checkbox.closest('.product-row');
          const price = parseFloat(productRow.dataset.price);
          const quantity = parseInt(productRow.querySelector('.quantity-input').value);
          total += price * quantity;
        });

        document.getElementById('subtotal').textContent = 'Rp. ' + total.toLocaleString('id-ID');
      }

      function submitForm(action, productId) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '';

        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = action;
        form.appendChild(actionInput);

        if (productId) {
          const productIdInput = document.createElement('input');
          productIdInput.type = 'hidden';
          productIdInput.name = 'product_id';
          productIdInput.value = productId;
          form.appendChild(productIdInput);
        }

        document.body.appendChild(form);
        form.submit();
      }

      function confirmCheckout() {
        const selectedProducts = Array.from(document.querySelectorAll('.product-checkbox:checked'))
          .map(checkbox => {
            const productRow = checkbox.closest('.product-row');
            return {
              product_id: checkbox.value,
              varian: productRow.querySelector('.product-varian').value,
              ukuran: productRow.querySelector('.product-ukuran').value
            };
          });

        if (selectedProducts.length === 0) {
          Swal.fire({
            title: "Peringatan",
            text: "Silakan pilih produk yang ingin di-checkout.",
            icon: "warning"
          });
          return;
        }

        Swal.fire({
            title: "Konfirmasi",
            text: "Apakah Anda yakin ingin checkout produk yang dipilih?",
            icon: "info",
            showCancelButton: true,
            confirmButtonText: "Ya",
            cancelButtonText: "Tidak",
          }).then((result) => {
              if (result.isConfirmed) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';

                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'checkout';
                form.appendChild(actionInput);

                selectedProducts.forEach(product => {
                  const productIdInput = document.createElement('input');
                  productIdInput.type = 'hidden';
                  productIdInput.name = 'selected_products[]';
                  productIdInput.value = JSON.stringify(product);
                  form.appendChild(productIdInput);
                });

                  document.body.appendChild(form);
                  form.submit();
              } 
            })
      }

      function handleSuccess() {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('success') === '1') {
          Swal.fire({
                title: "Sukses",
                text: "Pembelian Berhasil!",
                icon: "success",
              })
        } else if (urlParams.get('success') === '0') {
          Swal.fire({
            title: "Peringatan",
            text: "Silakan pilih produk yang ingin di-checkout.",
            icon: "warning"
          });
        }
      }

      window.onload = handleSuccess;
    </script>
  </body>
</html>
