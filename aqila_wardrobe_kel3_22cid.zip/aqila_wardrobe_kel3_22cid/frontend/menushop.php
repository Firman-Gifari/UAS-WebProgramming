<?php
require '../backend/conn.php';

// Ambil kategori dari parameter URL (default: 'All Products')
$category_filter = isset($_GET['category']) ? $_GET['category'] : '';

// Query produk berdasarkan kategori
$sql = "SELECT * FROM products";
$params = [];

if (!empty($category_filter) && $category_filter !== 'All Products') {
    $sql .= " WHERE category = ?";
    $params[] = $category_filter;
}

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
      html {
        scroll-behavior: smooth;
      }
    </style>
    <title>Produk Menu</title>
  </head>
  <body>
    <header class="flex items-center justify-between bg-indigo-600 py-4 px-4 text-white">
      <div class="flex items-center gap-2">
        <a href="landingpage.html">
          <img
            class="h-5 filter invert brightness-0"
            src="./img/arrowBack.png"
            alt="Kembali"
          />
        </a>
        <h1 class="text-2xl font-bold">Produk</h1>
      </div>
      <div class="flex items-center gap-2">
        <button
          type="button"
          class="inline-flex items-center justify-center gap-1.5 rounded border border-indigo-600 bg-white px-3 py-2 text-gray-900 transition hover:text-gray-700 focus:outline-none focus:ring text-sm text-indigo-600 font-medium"
        >
          <a href="cart.php?from=menushop"> Keranjang </a>
        </button>

        <button
          class="inline-flex items-center justify-center gap-1.5 rounded border border-indigo-600 bg-white px-3 py-2 text-gray-900 transition hover:text-gray-700 focus:outline-none focus:ring text-sm text-indigo-600 font-medium"
          type="button"
        >
          <a href="profile.html?from=menushop"> Akun </a>
        </button>
      </div>
    </header>

    <!-- Filter kategori -->
    <section
      id="filter"
      class="flex flex-wrap justify-end items-center gap-2 px-4 sm:mx-auto max-w-screen-xl pt-4 sm:px-6 sm:pt-12 lg:px-8"
    >
      <?php
        $categories = ['All Products', 'Casual Outfit', 'Muslim Outfit', 'Streetwear Outfit', 'Vintage Outfit'];
        foreach ($categories as $category):
            $activeClass = ($category_filter === $category || ($category_filter === '' && $category === 'All Products')) 
                ? 'bg-indigo-600 text-white' 
                : 'text-indigo-600';
      ?>
        <a
          class="inline-block rounded-sm border border-indigo-600 px-4 py-3 text-xs font-medium <?= $activeClass ?> hover:bg-indigo-600 hover:text-white focus:ring-3 focus:outline-hidden"
          href="?category=<?= urlencode($category) ?>"
        >
          <?= $category ?>
        </a>
      <?php endforeach; ?>
    </section>

    <section class="mx-auto max-w-screen-xl px-4 pb-8 sm:px-6 sm:pb-12 lg:px-8">
      <div>
        <h2 class="text-xl font-bold text-gray-900 sm:text-3xl">
          <?= $category_filter ? $category_filter : 'All Products' ?>
        </h2>

        <p class="mt-4 max-w-md text-gray-500">
          Berikut adalah kumpulan produk kami dalam kategori <strong><?= $category_filter ? $category_filter : 'All Products' ?></strong>.
        </p>
      </div>

      <!-- Daftar Produk -->
      <ul class="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <?php if (empty($products)): ?>
          <p class="text-gray-600">Tidak ada produk yang tersedia untuk kategori ini.</p>
        <?php else: ?>
          <?php foreach ($products as $product): ?>
            <li class="group block overflow-hidden">
              <a href="details.php?id=<?= $product['id'] ?>">
                <img
                  src="<?= $product['image_url'] ?>"
                  alt="<?= $product['name'] ?>"
                  class="h-[350px] w-full object-cover transition duration-500 group-hover:scale-105"
                >
                <div class="p-4">
                  <h3 class="font-medium text-gray-900"><?= $product['name'] ?></h3>
                  <p class="mt-2 text-gray-700">Rp <?= number_format($product['price'], 0, ',', '.') ?></p>
                  <span class="mt-2 inline-block text-sm text-gray-500">
                    Kategori: <?= $product['category'] ?>
                  </span>
                </div>
              </a>
            </li>
          <?php endforeach; ?>
        <?php endif; ?>
      </ul>
    </section>

    <footer>
      <div class="mx-auto max-w-screen-xl px-4 py-4 sm:px-6 lg:px-8">
        <div class="text-center">
          <p class="text-xs text-gray-600">
          @Copyright by 22552011189, 22552011041, 22552011074, 22552011171,
            22552011183_Kelompok 3 Aridwan, Davin Albar Pratama, Dzikri Ali
            Al-Hafidzi, Ega Sulanjana, Firman Gifari_TIF 22 CID
          </p>
        </div>
      </div>
    </footer>

    
  </body>
</html>
