<?php
session_start();
header('Content-Type: application/json');
include 'conn.php'; // Koneksi database

$response = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validasi input
    if (empty($nama) || empty($email) || empty($password)) {
        $response = [
            'success' => false,
            'message' => 'Semua kolom wajib diisi'
        ];
        echo json_encode($response);
        exit;
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Cek apakah email sudah terdaftar
        $check_query = "SELECT email FROM data_user WHERE email = :email";
        $stmt = $conn->prepare($check_query);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $response = [
                'success' => false,
                'message' => 'Email sudah terdaftar. Gunakan email lain.'
            ];
        } else {
            // Jika email belum terdaftar, lakukan pendaftaran
            $query = "INSERT INTO data_user (nama, email, password) VALUES (:nama, :email, :password)";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':nama', $nama, PDO::PARAM_STR);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->bindParam(':password', $hashed_password, PDO::PARAM_STR);
            
            if ($stmt->execute()) {
                $response = [
                    'success' => true,
                    'message' => 'Registrasi berhasil!'
                ];
            } else {
                $response = [
                    'success' => false,
                    'message' => 'Gagal mendaftar.'
                ];
            }
        }
    } catch (PDOException $e) {
        $response = [
            'success' => false,
            'message' => 'Terjadi kesalahan: ' . $e->getMessage()
        ];
    }
} else {
    $response = [
        'success' => false,
        'message' => 'Metode request tidak valid'
    ];
}

echo json_encode($response);
?>