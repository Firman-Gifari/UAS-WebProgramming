<?php
session_start();
header('Content-Type: application/json'); 

include 'conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['session_token'])) {
        echo json_encode(["success" => false, "message" => "User belum login."]);
        exit;
    }

    $session_token = $_SESSION['session_token'];
    try {
        $query = "UPDATE data_user SET session_token = NULL WHERE session_token = :session_token";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':session_token', $session_token, PDO::PARAM_STR);

        if ($stmt->execute()) {
            session_destroy(); 
            echo json_encode(["success" => true, "message" => "Logout berhasil!"]);
        } else {
            echo json_encode(["success" => false, "message" => "Logout gagal, coba lagi."]);
        }
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Terjadi kesalahan: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Metode request tidak valid."]);
}
?>