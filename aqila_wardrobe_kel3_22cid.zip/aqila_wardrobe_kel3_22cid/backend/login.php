<?php
session_start();
header('Content-Type: application/json');
include 'conn.php'; // Pastikan koneksi ke database menggunakan PDO

$response = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        echo json_encode([
            'success' => false,
            'message' => 'Email dan password wajib diisi'
        ]);
        exit;
    }

    try {
        // Ambil user berdasarkan email
        $query = "SELECT * FROM data_user WHERE email = :email LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // Buat session token unik
            $session_token = bin2hex(random_bytes(32));

            // Simpan token di database
            $update_query = "UPDATE data_user SET session_token = :session_token WHERE id = :id";
            $stmt_update = $conn->prepare($update_query);
            $stmt_update->bindParam(':session_token', $session_token, PDO::PARAM_STR);
            $stmt_update->bindParam(':id', $user['id'], PDO::PARAM_INT);
            $stmt_update->execute();

            // Simpan di sesi PHP
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['session_token'] = $session_token;

            // Hapus password sebelum mengirim respons ke client
            unset($user['password']);
            $user['session_token'] = $session_token;

            echo json_encode([
                'success' => true,
                'message' => 'Login berhasil',
                'user_data' => $user
            ]);
            exit;
        }

        // Jika email tidak ditemukan atau password salah
        echo json_encode([
            'success' => false,
            'message' => 'Email atau password salah'
        ]);
        exit;
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Terjadi kesalahan: ' . $e->getMessage()
        ]);
        exit;
    }
}

// Jika request bukan POST
echo json_encode([
    'success' => false,
    'message' => 'Metode request tidak valid'
]);
exit;

?>
