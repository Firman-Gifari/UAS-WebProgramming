<?php
session_start();
header('Content-Type: application/json');
include 'conn.php'; // Koneksi database

$response = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $new_password = $_POST['new_password'] ?? '';

    // Validasi input
    if (empty($email) || empty($new_password)) {
        $response = [
            'success' => false,
            'message' => 'Email dan password baru harus diisi.'
        ];
        echo json_encode($response);
        exit;
    }

    try {
        // Periksa apakah email terdaftar di database
        $query = "SELECT id FROM data_user WHERE email = :email";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->rowCount() == 0) {
            $response = [
                'success' => false,
                'message' => 'Email tidak terdaftar.'
            ];
            echo json_encode($response);
            exit;
        }

        // Ambil ID pengguna
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        $user_id = $user['id'];

        // Enkripsi password baru
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Update password di database
        $update_query = "UPDATE data_user SET password = :password WHERE id = :id";
        $stmt = $conn->prepare($update_query);
        $stmt->bindParam(':password', $hashed_password, PDO::PARAM_STR);
        $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $response = [
                'success' => true,
                'message' => 'Password berhasil diperbarui.'
            ];
        } else {
            $response = [
                'success' => false,
                'message' => 'Gagal memperbarui password.'
            ];
        }
    } catch (PDOException $e) {
        $response = [
            'success' => false,
            'message' => 'Terjadi kesalahan: ' . $e->getMessage()
        ];
    }
} else {
    $response = [
        'success' => false,
        'message' => 'Hanya menerima metode POST.'
    ];
}

echo json_encode($response);
?>