<?php
    $host = "localhost"; // Nama host (biasanya localhost)
    $username = "root"; // Username default XAMPP adalah "root"
    $password = ""; // Kosongkan jika pakai XAMPP
    $database = "uas"; // Ganti dengan nama database Anda

    try {
        $conn = new PDO("mysql:host=$host;dbname=$database", $username, $password);
        // echo "Koneksi Berhasil!";
    } catch (PDOException $cek_koneksi) {
        die($cek_koneksi->getMessage());
    }

?>
