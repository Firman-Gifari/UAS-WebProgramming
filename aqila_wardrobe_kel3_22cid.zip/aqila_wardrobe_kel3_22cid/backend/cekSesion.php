<?php
session_start();
header('Content-Type: application/json');
include 'conn.php';

if (!function_exists('checkUserLogin')) {
    function checkUserLogin($conn) {
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_token'])) {
            return false; // Jangan echo JSON di sini
        }

        $user_id = $_SESSION['user_id'];
        $session_token = $_SESSION['session_token'];

        $query = "SELECT id FROM data_user WHERE id = :id AND session_token = :token LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':token', $session_token, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->rowCount() > 0;
    }
}

// Pengecekan status login
if (checkUserLogin($conn)) {
    echo json_encode(["success" => true, "message" => "User masih login."]);
} else {
    echo json_encode(["success" => false, "message" => "User tidak terautentikasi."]);
}
exit;

?>