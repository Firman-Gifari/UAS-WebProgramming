<?php
// Koneksi ke database
include 'conn.php'; // Pastikan file connn.php berisi koneksi database dengan PDO

// Cek apakah session sudah dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Pastikan pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "Harap login terlebih dahulu."]);
    exit();
}

header('Content-Type: application/json'); // Set response ke JSON

// Endpoint untuk mengubah data profil
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari request
    $user_id = $_SESSION['user_id'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $no_telpon = $_POST['no_telpon'];
    $alamat = $_POST['alamat'];
    $gender = $_POST['gender'];

    // Update data di database
    $query = "UPDATE data_user SET tanggal_lahir = ?, no_telpon = ?, alamat = ?, gender = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $result = $stmt->execute([$tanggal_lahir, $no_telpon, $alamat, $gender, $user_id]);

    if ($result) {
        echo json_encode(["success" => true, "message" => "Profil berhasil diperbarui."]);
    } else {
        echo json_encode(["success" => false, "message" => "Gagal memperbarui profil."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Hanya menerima metode POST."]);
}
?>
